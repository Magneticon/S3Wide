#!/bin/sh
set -eu

if [ -z "${WATCOM:-}" ]; then
    echo "set WATCOM to the Open Watcom V2 root" >&2
    exit 2
fi
OWBIN=${OWBIN:-binl64}
S3_LDRCAN_ASSEMBLER=${S3_LDRCAN_ASSEMBLER:-$WATCOM/$OWBIN/wasm}
S3_LDRCAN_LINKER=${S3_LDRCAN_LINKER:-$WATCOM/$OWBIN/wlink}
S3_LDRCAN_DUMPER=${S3_LDRCAN_DUMPER:-$WATCOM/$OWBIN/wdump}
S3_LDRCAN_DISASSEMBLER=${S3_LDRCAN_DISASSEMBLER:-$WATCOM/$OWBIN/wdis}
BUILD_DIR=${S3_LDRCAN_BUILD_DIR:-build}
OUTPUT_NAME=${S3_LDRCAN_OUTPUT_NAME:-S3LDRCAN}
if [ ! -x "$S3_LDRCAN_ASSEMBLER" ]; then
    echo "missing executable assembler: $S3_LDRCAN_ASSEMBLER" >&2
    exit 2
fi
if [ ! -x "$S3_LDRCAN_LINKER" ]; then
    echo "missing executable linker: $S3_LDRCAN_LINKER" >&2
    exit 2
fi
if [ ! -f "$WATCOM/$OWBIN/wlink.lnk" ]; then
    echo "missing Open Watcom linker system definitions: $WATCOM/$OWBIN/wlink.lnk" >&2
    exit 2
fi

mkdir -p "$BUILD_DIR"
python3 check_candidate_source.py include/win30vxd.inc
rm -f "$BUILD_DIR/s3ldrcan.obj" "$BUILD_DIR/$OUTPUT_NAME.386" "$BUILD_DIR/s3ldrcan.map" \
    "$BUILD_DIR/link.lnk" "$BUILD_DIR/exports.txt" "$BUILD_DIR/fixups.txt" \
    "$BUILD_DIR/assembler-version.txt" "$BUILD_DIR/linker-version.txt" "$BUILD_DIR/tool-sha256.txt" \
    "$BUILD_DIR/disassembly.txt"

if ! "$S3_LDRCAN_ASSEMBLER" -? > "$BUILD_DIR/assembler-version.txt" 2>&1; then
    grep -q 'Open Watcom x86 Assembler Version' "$BUILD_DIR/assembler-version.txt"
fi
"$S3_LDRCAN_LINKER" -? > "$BUILD_DIR/linker-version.txt" 2>&1
sha256sum "$S3_LDRCAN_ASSEMBLER" "$S3_LDRCAN_LINKER" > "$BUILD_DIR/tool-sha256.txt"

if [ "${S3_LDRCAN_DEBUG_BREAK:-0}" = 1 ]; then
    "$S3_LDRCAN_ASSEMBLER" -3p -zq -dS3LDRCAN_DEBUG_BREAK=1 -i=include \
        -fo="$BUILD_DIR/s3ldrcan.obj" src/s3ldrcan.asm
else
    "$S3_LDRCAN_ASSEMBLER" -3p -zq -i=include -fo="$BUILD_DIR/s3ldrcan.obj" src/s3ldrcan.asm
fi
{
    printf '@%s/%s/wlink.lnk\n' "$WATCOM" "$OWBIN"
    printf 'system win_vxd\n'
    printf 'name %s/%s.386\n' "$BUILD_DIR" "$OUTPUT_NAME"
    printf 'file %s/s3ldrcan.obj\n' "$BUILD_DIR"
    printf 'export S3LDRCAN_DDB.1\n'
    printf 'option quiet,map=%s/s3ldrcan.map\n' "$BUILD_DIR"
} > "$BUILD_DIR/link.lnk"
"$S3_LDRCAN_LINKER" @"$BUILD_DIR/link.lnk"

python3 inspect.py "$BUILD_DIR/$OUTPUT_NAME.386" "$BUILD_DIR/s3ldrcan.map"
if [ -x "$S3_LDRCAN_DUMPER" ]; then
    "$S3_LDRCAN_DUMPER" -x "$BUILD_DIR/$OUTPUT_NAME.386" > "$BUILD_DIR/exports.txt"
    if ! grep -Eq 'S3LDRCAN_DDB[[:space:]]+@1' "$BUILD_DIR/exports.txt"; then
        echo "DDB is not exported at ordinal 1" >&2
        exit 1
    fi
    "$S3_LDRCAN_DUMPER" -f "$BUILD_DIR/$OUTPUT_NAME.386" > "$BUILD_DIR/fixups.txt"
    printf 'PASS: wdump confirms DDB ordinal 1 and relocation data\n'
else
    echo "wdump not found; export ordinal is declared in build/link.lnk but not independently dumped" >&2
fi
if [ "${S3_LDRCAN_DEBUG_BREAK:-0}" = 1 ] && [ -x "$S3_LDRCAN_DISASSEMBLER" ]; then
    "$S3_LDRCAN_DISASSEMBLER" -l="$BUILD_DIR/disassembly.txt" "$BUILD_DIR/s3ldrcan.obj"
    if ! grep -Eiq 'int[[:space:]]+(3|0x03)' "$BUILD_DIR/disassembly.txt"; then
        echo "debug build is missing the Device_Init breakpoint instruction" >&2
        exit 1
    fi
fi
sha256sum include/win30vxd.inc src/s3ldrcan.asm "$BUILD_DIR/$OUTPUT_NAME.386" \
    > "$BUILD_DIR/SHA256SUMS.txt"
printf 'VxD output: '
file "$BUILD_DIR/$OUTPUT_NAME.386"
