# S3LDRCAN no-I/O VxD loader canary

This is a separate, project-authored static VxD canary. It exists only to test
whether the licensed Open Watcom candidate DDB declaration can be loaded by a
WfW 3.11 guest. It has no PM or V86 API, no VMM service table/calls, no port
I/O, no memory mapping, and no S3 register or framebuffer access. Every
control message is accepted without a side effect; `Device_Init` returns with
carry clear. It is not an S3 provider or usable display driver.

## Source and license provenance

`include/win30vxd.inc` is an unmodified copy of the Open Watcom V2 public
header from commit `08a5064dd9831edf10234844630e605e83606989`, path
`bld/watcom/h/win30vxd.inc`, SHA-256
`13c2711313419f9144972a670b93627ca92246640b25910c7d29d9d73010ab13`.
It retains the source copyright and Sybase Open Watcom Public License notice;
the full license is adjacent. The project source in `src/s3ldrcan.asm` is
independently written and calls only the licensed include's
`Declare_Virtual_Device`, `Control_Dispatch`, segment, and constant
definitions. No AHCIFIX or Microsoft DDK source/binary is included.
The Open Watcom V2 2.0 toolchain package identity and hash are recorded in
[`TOOLCHAIN-PROVENANCE.md`](TOOLCHAIN-PROVENANCE.md); exact assembler/linker
hashes and version strings are in `build/`.

The source-defined prefix fields and offsets are preserved here for review:

| Offset | Field | Bytes |
| ---: | --- | ---: |
| 0 | Next link | 4 |
| 4 | SDK version (`0x030A`) | 2 |
| 6 | Requested device number (`UNDEFINED_DEVICE_ID=0`) | 2 |
| 8 | Major version | 1 |
| 9 | Minor version | 1 |
| 10 | Flags | 2 |
| 12 | Eight-byte name | 8 |
| 20 | Initialization order (`0x80000000`) | 4 |
| 24 | Control procedure pointer | 4 |
| 28 | V86 API pointer | 4 |
| 32 | PM API pointer | 4 |
| 36 | V86 API entry CS:IP | 4 |
| 40 | PM API entry CS:IP | 4 |
| 44 | Reference data | 4 |
| 48 | Service-table pointer | 4 |
| 52 | Service-table size | 4 |

The include appends `DDB_Win32_Service_Table`, `DDB_Prev`, `DDB_Size`, and
three reserved DWORDs at offsets 56 through 76 (24 bytes total, with size 80).
Those tail fields are explicitly labeled Windows 9x/Me in the source. The
canary image contains that tail; Windows 3.11 ignoring it is a runtime
question.

The DDB values emitted by this include are a **candidate**, not a claim of
WfW 3.11 conformance. The static checker confirms the bytes in this build
against the same field declarations; it does not independently validate the
Windows ABI. In particular, the include has a `30Ah` SDK-version default and
a 24-byte Windows 9x/Me tail. The local WfW test must establish whether
Windows 3.11 accepts this record and ignores that tail.

## Rebuild and static checks

From this directory with an executable Open Watcom V2 installation:

```sh
WATCOM=/path/to/open-watcom-v2 OWBIN=binl64 ./build.sh
```

`S3_LDRCAN_ASSEMBLER` and `S3_LDRCAN_LINKER` may override the executables when
the extracted package's file permissions need repair. The recipe uses the
installed `wlink.lnk`
definition for `system win_vxd`, exports `S3LDRCAN_DDB` at ordinal 1, links
`build/S3LDRCAN.386`, checks its LE header and emitted DDB fields, and writes
`build/SHA256SUMS.txt`. When `wdump` is installed, it also confirms the
`S3LDRCAN_DDB @1` export and records the LE fixup table; the linker directive
already assigns ordinal 1. `check_candidate_source.py` pins the retained
Open Watcom include hash and the candidate service constants for
`Get_Sys_VM_Handle`, `Allocate_PM_Call_Back`, and `Map_Flat`; these are not
verified Windows 3.1 service numbers. All these checks validate a source and
linker candidate, not WfW DDB conformance. The recipe does not run the VxD.

## Positive control-dispatch observation

A clean Windows desktop alone is not evidence that this VxD's
`Device_Init` control procedure ran. The ordinary `S3LDRCAN.386` image is a
boot-regression canary; if Windows reaches Program Manager, report that as
"boot completed with the canary configured," not as a load/control pass.

For a positive dispatch observation, build a separate image with an INT 3 at
the first instruction of the `Device_Init` handler:

```sh
WATCOM=/path/to/open-watcom-v2 OWBIN=binl64 \
S3_LDRCAN_DEBUG_BREAK=1 S3_LDRCAN_BUILD_DIR=build-debug \
S3_LDRCAN_OUTPUT_NAME=S3LDRDBG ./build.sh
```

This variant is only for a disposable WfW clone started under WDEB386 with a
debugging `WIN386.EXE` installed and connected. Microsoft KB Q72379 documents
INT 3 as a WDEB386 breakpoint and explains that the debugger can trace VxD
code. The debugger must stop at the canary's handler breakpoint during VxD
initialization. The disassembly places INT 3 immediately after the
`Control_Dispatch` comparison for `Device_Init`; record the stop address and
confirm `EAX=1` (the dispatched `Device_Init` message), then continue and
confirm startup completes. That hit proves dispatch
reached this canary's `Device_Init`; it does not prove later control messages
or provider functionality. The breakpoint build must not be used with retail
WIN386 or without a functioning debugger. If the required debug environment is
unavailable, skip this variant and keep the result at the boot-regression
level. Microsoft KB Q76473 also warns that `Debug_Out`/`Trace_Out` produce no
output unless the debugging `WIN386.EXE` is installed, so those macros are
not treated as a retail-build observation channel.

For that run only, copy `build-debug/S3LDRDBG.386` to the disposable guest's
Windows SYSTEM directory and use `device=S3LDRDBG.386`. Do not combine the
ordinary and breakpoint images in one test.

The DDK's INT 2Fh/1605h broadcast is used to assemble the list of VxDs Windows
should load; it is not a documented inventory of VxDs already loaded. The DDK
also documents `SHELL_SYSMODAL_Message`, but using it here would require the
missing matching `shell.inc`/service linkage and a verified point after the
Shell service is ready. No non-debug positive load signal is currently
implemented or validated. See
[`../../evidence/vxd-contract-alternatives.md`](../../evidence/vxd-contract-alternatives.md)
for the source-backed ID collision and observation findings.

## Disposable guest test

Use only the local task's verified WfW guest clone and rollback manifest. Do
not edit its source disk or the ATALANTA workspace. First record the clone's
hashes/config and keep the stock VGA setup as the recovery baseline. Copy
`build/S3LDRCAN.386` to the clone's Windows SYSTEM directory and add only
`device=S3LDRCAN.386` in the clone's `[386Enh]` section. Cold-boot Windows
normally, then confirm USER/Program Manager and font initialization complete.
Do not select the S3 DDA, change display mode, run DOS applications, or use
any hardware access. On any boot error, hang, or warning, stop and discard the
clone. After a clean result, remove the one line, verify the original clone
files against the rollback manifest, and report the exact WfW build,
DOSBox-X version/config, binary hash, boot log, and observed result.

A successful boot only shows that configuring the ordinary canary did not
prevent startup on that exact guest. A debugger breakpoint in the separate
diagnostic image is the positive observation for `Device_Init`. Neither
validates an exported PM API, a guest-checked lab ID mapping, VMM service
calls, S3 VDD/grabber compatibility, port traps, framebuffer mapping, bank switching,
mode programming, or Windows GDI. See
[`win16-ping-contract.md`](win16-ping-contract.md) for the next, no-hardware
API probe design and its lab-ID ownership gate. The currently built Win16
client is blocked by default and its build/hash record is in
[`../../evidence/vxd-ping-client-build.md`](../../evidence/vxd-ping-client-build.md).
