#!/usr/bin/env python3
"""Pin and sanity-check the licensed Open Watcom VxD candidate declarations.

These checks validate the retained candidate input only. They do not claim
that win30vxd.inc is the Windows 3.1/WfW 3.11 DDK contract.
"""

from hashlib import sha256
from pathlib import Path
import re
import sys


EXPECTED_SHA256 = "13c2711313419f9144972a670b93627ca92246640b25910c7d29d9d73010ab13"
EXPECTED_SERVICES = {
    "Get_Sys_VM_Handle": "0010003h",
    "Allocate_PM_Call_Back": "001000Ch",
    "Map_Flat": "001001Ch",
}


def fail(message: str) -> None:
    raise SystemExit(f"FAIL: {message}")


if len(sys.argv) != 2:
    fail("usage: check_candidate_source.py include/win30vxd.inc")

path = Path(sys.argv[1])
source_bytes = path.read_bytes()
source = source_bytes.decode("ascii")
digest = sha256(source_bytes).hexdigest()
if digest != EXPECTED_SHA256:
    fail(f"retained Open Watcom input hash changed: {digest}")

for name, expected in EXPECTED_SERVICES.items():
    match = re.search(rf"(?m)^\s*{re.escape(name)}\s*=\s*([0-9A-Fa-f]+h)\s*$", source)
    if not match:
        fail(f"missing candidate service constant {name}")
    if match.group(1).lower() != expected.lower():
        fail(f"{name}: got {match.group(1)}, expected {expected}")

ddb = re.search(
    r"(?ms)^\s*Declare_Virtual_Device\s+macro\b.*?^\s*endm\s*$", source
)
if not ddb:
    fail("missing candidate Declare_Virtual_Device macro")
if "OFFSET Ctrl_Proc, 0, 0,,, 0, 0, 0" not in ddb.group(0):
    fail("candidate macro no longer shows its zero API/service initializers")

dispatch = re.search(
    r"(?ms)^\s*Control_Dispatch\s+macro\b.*?^\s*endm\s*$", source
)
if not dispatch or not re.search(r"(?m)^\s*cmp\s+eax,\s*Service\s*$", dispatch.group(0), re.I):
    fail("candidate Control_Dispatch no longer compares the message in EAX")

print(f"PASS: pinned licensed candidate include SHA-256 {digest}")
print("Candidate service IDs: Get_Sys_VM_Handle=0x0010003, "
      "Allocate_PM_Call_Back=0x001000C, Map_Flat=0x001001C")
print("Candidate macro leaves PM/V86 API and service-table fields zero")
print("Candidate Control_Dispatch compares the message in EAX")
print("These are Open Watcom candidate declarations, not WfW 3.11 validation")
