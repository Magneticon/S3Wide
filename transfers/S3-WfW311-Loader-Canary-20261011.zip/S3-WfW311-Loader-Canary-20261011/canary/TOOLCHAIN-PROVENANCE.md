# Build toolchain provenance

The cloud build used Open Watcom V2 2.0 C/C++ Linux x86_64, official
GitHub `Current-build` distribution downloaded 2026-10-09. Distribution
SHA-256:

```text
cd922f6200a20505cdda44dc0155471ae3d3f53e33a354097f3d89de74dc49c6
```

The assembler and linker version strings and their exact executable hashes
from the successful build are preserved in `build/assembler-version.txt`,
`build/linker-version.txt`, and `build/tool-sha256.txt`. The toolchain and the
retained `win30vxd.inc` are governed by the Sybase Open Watcom Public License
1.0; `include/OPEN_WATCOM_LICENSE.txt` contains that license text.

The installed `wlink.lnk` declares `system win_vxd` as `format windows vxd`.
The cloud build only used the installed assembler, linker, and inspection
utility. No Microsoft DDK binaries or sample code were used.
