; Project-owned no-I/O VxD loader canary.
; The DDB and helper macros below come from the licensed Open Watcom
; win30vxd.inc, retained alongside this source. Runtime WfW 3.11 compatibility
; is an experiment and is not implied by the include's name or SDK field.

.386p
include win30vxd.inc

S3LDRCAN_INIT_ORDER EQU 080000000H

; Device ID zero is the include's UNDEFINED_DEVICE_ID. This canary exports no
; V86 or PM API and has no VMM service table, so it is not an API provider.
Declare_Virtual_Device S3LDRCAN, 1, 0, S3LDRCAN_Control, \
                       UNDEFINED_DEVICE_ID, S3LDRCAN_INIT_ORDER, , , 0

VxD_LOCKED_CODE_SEG
    ; Keep the function's segment-relative offset nonzero for the static
    ; relocation check; this is an inert instruction, not device activity.
    nop
S3LDRCAN_Control PROC NEAR
    Control_Dispatch DEVICE_INIT, S3LDRCAN_Device_Init
    ; This handler intentionally accepts other lifecycle messages without
    ; side effects. It performs no allocation, I/O, mapping, or state change.
    clc
    ret

S3LDRCAN_Device_Init:
IFDEF S3LDRCAN_DEBUG_BREAK
    ; Separate diagnostic build only. Use only with a WDEB386-connected
    ; debugging WIN386; the breakpoint proves dispatch reached Device_Init.
    int 3
ENDIF
    clc
    ret
S3LDRCAN_Control ENDP
VxD_LOCKED_CODE_ENDS

END
