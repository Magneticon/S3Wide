# Win16 to VxD no-hardware ping contract (draft)

## What is documented and what is project-defined

The documented Windows 3.0/3.1 transport is `INT 2Fh` with `AX=1684h` and
`BX` set to the provider's VxD ID. It returns a protected-mode API entry in
`ES:DI`, which the Win16 caller invokes with a far call. Windows DDK KB Q120079
requires treating `ES=0` as discovery failure even when `DI` is nonzero. The
VxD-specific function parameters and response are defined by the VxD; the
following small ping is a project contract, not a Microsoft ABI.

The API probe uses only CPU registers and a far call. It must not make VMM
service calls, read or write S3/VGA ports, map/read/write video memory, set a
video mode, or modify DOS grabber state.

## Production registration versus a lab identifier

Microsoft's historical DDK guidance describes official ID registration for
production VxDs. That is separate from a private, disposable experiment. For
a local test, `S3_VXD_ID` may be an explicitly supplied, nonzero lab candidate
copied identically into the test DDB and the Win16 request. **Inference from
the DDK lookup rules:** this should be technically sufficient for local
`INT 2Fh/1684h` discovery if the candidate uniquely identifies the loaded test
VxD. It is not an officially assigned ID, does not imply a private number
range, and must not be distributed.

Q84000 documents Windows detecting the same uniquely identified VxD when it
is listed more than once; it does not establish a general cross-name collision
query. The workspace has no validated loaded-DDB inventory or VMM lookup that
can prove a candidate belongs to this test VxD. `INT 2Fh/1684h` alone is not
that check: a returned pointer only shows that some PM API was found for the
ID. The probe may be built with a lab candidate, but it must not far-call the
pointer until a guest-specific ownership check is established.

## Draft v1 ping ABI

The Win16 app performs these steps:

1. Require a nonzero lab candidate explicitly supplied as `S3_VXD_ID`. Do not
   use `UNDEFINED_DEVICE_ID` or copy another driver's ID. This candidate is
   only for an undistributed disposable test, not official registration.
   The built client reports `BLOCKED` and makes no INT 2Fh request by default.
   The separate `S3_VXD_OWNER_CHECKED=1` flag is an operator gate to be used
   only after recording the guest-specific ownership check; it does not
   perform that check itself.
2. Call `INT 2Fh` with `AX=1684h`, `BX=S3_VXD_ID`.
3. If returned `ES=0`, report discovery failure and do not call `ES:DI`.
4. Far-call the returned entry as `DWORD FAR PASCAL api(WORD op, WORD abi,
   WORD nonce)` with `op=5300h` (PING), `abi=0100h` (v1.0), and
   `nonce=6D31h`.
5. Require return `DX:AX=5331:6D31h`. The high word is the `S3`/version
   response signature; the low word echoes the nonce. Any other value is a
   failed negotiation. The request performs no allocation or lasting state
   change.

The Win16 side uses a 16:16 far function pointer and 16-bit PASCAL stack
arguments. A future VxD must explicitly implement this exact register/stack
contract and return `DX:AX` as above. This ABI does not claim that an arbitrary
WfW VxD uses this convention.

## Positive and negative test criteria

The positive test requires a matching no-hardware test VxD, a lab candidate
confirmed to identify that DDB in the disposable guest, and a WfW-compatible
API-bearing DDB/entry adapter. Record the candidate origin, ownership check,
VxD/DDA hashes, WfW build, and probe result. Positive means discovery
returned nonzero `ES` and the far call returned the exact signature/nonce.
Never call a pointer after `ES=0` or before provider ownership is established.

The negative path can be checked with a guest-verified unused candidate;
require `ES=0` and zero far-call count. Do not choose ID zero: Windows defines
it as `UNDEFINED_DEVICE_ID`, which cannot identify an exported PM API. Q84000
describes per-VxD official IDs for production but documents no lab range.

## Current gate

The local canary intentionally exports no PM API, and the installed Open
Watcom macro writes zero to its API fields. The project still lacks an
independently validated WfW 3.11 API-bearing DDB/entry adapter and a
guest-specific lab-candidate ownership check. The client may be built with a
nonzero lab candidate, but no provider call is authorized until those
technical gates are resolved. Official registration is a separate
pre-distribution requirement. Keep `Enable` fail-closed and S3 hardware
access disabled.

After the matching no-hardware provider and guest-specific ownership check
exist, build the Win16 client from its `win16/` subdirectory with
`WATCOM=/path/to/open-watcom-v2 OWBIN=binl64 S3_VXD_ID=0xHHHH
./build-vxd-ping-probe.sh`. The call arguments and response are this project's
ping protocol, not a Windows ABI. A client build alone does not prove DDB
compatibility or candidate ownership.

## Sources

* [Microsoft DDK KB Q89705: How VMs Can Communicate with VxDs](https://helparchive.huntertur.net/document/45391)
* [Microsoft DDK KB Q120079: INT 2Fh 1684h callback selector failure](https://helparchive.huntertur.net/document/45408)
* [Microsoft DDK KB Q84000: Obtaining a VxD ID Number](https://helparchive.huntertur.net/document/45400)
