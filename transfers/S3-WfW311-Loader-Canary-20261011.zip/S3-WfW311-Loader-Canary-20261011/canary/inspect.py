#!/usr/bin/env python3
"""Check the emitted no-API DDB fields in a linked LE VxD canary."""

from pathlib import Path
import struct
import sys


def fail(message: str) -> None:
    raise SystemExit(f"FAIL: {message}")


if len(sys.argv) != 3:
    fail("usage: inspect.py candidate.386 linker.map")

image_path = Path(sys.argv[1])
map_path = Path(sys.argv[2])
image = image_path.read_bytes()
map_text = map_path.read_text(errors="replace")

if len(image) < 64 or image[:2] != b"MZ":
    fail("missing MZ DOS stub")
le_offset = struct.unpack_from("<I", image, 0x3C)[0]
if le_offset + 4 > len(image) or image[le_offset:le_offset + 2] != b"LE":
    fail("missing LE VxD header")

name = b"S3LDRCAN"
name_offsets = []
start = 0
while True:
    name_offset = image.find(name, start)
    if name_offset < 0:
        break
    if name_offset >= 8 and struct.unpack_from("<H", image, name_offset - 8)[0] == 0x030A:
        name_offsets.append(name_offset)
    start = name_offset + 1
if len(name_offsets) != 1:
    fail(f"expected one DDB name preceded by SDK version 0x030A; found {len(name_offsets)}")
name_offset = name_offsets[0]
ddb_offset = name_offset - 12
if ddb_offset < 0 or ddb_offset + 80 > len(image):
    fail("DDB candidate lies outside the linked file")
ddb = image[ddb_offset:ddb_offset + 80]

def u16(offset: int) -> int:
    return struct.unpack_from("<H", ddb, offset)[0]


def u32(offset: int) -> int:
    return struct.unpack_from("<I", ddb, offset)[0]


checks = {
    "SDK version": (u16(4), 0x030A),
    "device ID": (u16(6), 0),
    "major version": (ddb[8], 1),
    "minor version": (ddb[9], 0),
    "flags": (u16(10), 0),
    "init order": (u32(20), 0x80000000),
    "V86 API pointer": (u32(28), 0),
    "PM API pointer": (u32(32), 0),
    "V86 API entry": (u32(36), 0),
    "PM API entry": (u32(40), 0),
    "reference data": (u32(44), 0),
    "service table pointer": (u32(48), 0),
    "service table size": (u32(52), 0),
    "Win9x tail size field": (u32(64), 80),
}
if u32(24) == 0:
    fail("control procedure pointer is zero")
for label, (actual, expected) in checks.items():
    if actual != expected:
        fail(f"{label}: got 0x{actual:X}, expected 0x{expected:X}")
if ddb[12:20] != name:
    fail("DDB name field mismatch")
if any(ddb[offset:offset + 4] != b"\0" * 4 for offset in (56, 60, 68, 72, 76)):
    fail("unexpected nonzero Windows 9x/Me tail field")
if "S3LDRCAN_DDB" not in map_text:
    fail("linker map does not name the exported DDB")

print(f"LE header offset: 0x{le_offset:X}")
print(f"DDB file offset: 0x{name_offset - 12:X}")
print("DDB prefix: 56 bytes; SDK=0x030A; ID=0; version=1.0; init=0x80000000")
print("DDB APIs/services: all absent; control procedure pointer is nonzero")
print("Win9x/Me extension: 24 bytes, size field=80")
print("Export symbol: S3LDRCAN_DDB; link directive requests ordinal 1")
print("PASS: static fields match the Open Watcom declaration used to build this canary")
