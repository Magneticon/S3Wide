# Minimal WfW 3.11 loader-canary guest plan — 2026-10-11

## Guest identity and current access

The consumer-reported WfW 3.11 guest uses DOSBox-X
`C:\\DOSBox-X\\dosbox-x.exe`, version `2026.08.31`, SHA-256
`2980380AB589A561EEDA3028AB955BC27137BD1710533B325F41144ECD460801`, and
config `C:\\CODEX\\GIT\\S3\\test\\dosbox-x.conf`. It selects
`svga_s3trio64`, `vmemsize=4` MiB, and mounts host `C:\\CODEX\\DOS`.
The reported stock-VGA baseline uses a 15,177,814-byte `VGA.DRV`; `S3.DRV`
is absent. Earlier guest evidence reported Program Manager in Enhanced Mode,
`*VDDVGA`, and 640x480.

The helper reports a separate clone at
`C:\\CODEX\\2026-10-11\\task-2\\s3-vxcanary-prep\\disposable-guest`
and an untouched, read-only rollback copy at
`C:\\CODEX\\2026-10-11\\task-2\\s3-vxcanary-prep\\rollback-baseline`,
with `manifest.json`. The helper reports all 277 clone files match
`C:\\CODEX\\DOS` and no guest is running. These facts are user-reported;
they have not been independently rehashed in this workspace. Keep
`C:\\CODEX\\DOS`, `C:\\DOS`, and `C:\\DOS - Copy` untouched. Do not
access or edit the ATALANTA workspace.

The exact guest-side Windows SYSTEM directory and the artifact transfer mount
drive letter still need to be read from the clone's DOSBox-X config and guest
layout. Do not guess a guest path. No guest has been launched or modified by
this task.

## Safe test inputs

The ordinary no-I/O canary is `tests/vxd-loader-canary/build/S3LDRCAN.386`,
500 bytes, SHA-256
`ec34a802e00bf4235ba314ae683e0ff73edcbefe8486ef396b4582c8a46b72cf`.
It has no API, VMM service calls, port I/O, video-memory mapping, or S3 access.
It accepts control messages and returns carry clear. A clean boot with this
image configured is only a startup regression result; it does **not** prove
`Device_Init` ran.

The positive-control variant is
`tests/vxd-loader-canary/build-debug/S3LDRDBG.386`, 500 bytes, SHA-256
`ed2ed0e42996d2576b5f30ea3782d219d6d8c0332422bfcfddab78e2a434d9f2`. It
contains an `INT 3` at the `Device_Init` branch. DOSBox-X's existing
debugger may provide the breakpoint without installing WDEB386; see
`evidence/dosbox-x-debugger-feasibility.md`. The reported executable's
`C_DEBUG` support and live `BPINT 03` behavior are not yet confirmed. Do
not stage the debug image unless that preflight succeeds. Otherwise, use only
a matching debugging `WIN386.EXE` with WDEB386 attached before Windows
starts. Never allow an unhandled `INT 3` to reach a retail kernel.

## Preconditions before any guest change

1. The user has authorized one bounded no-output canary test in the disposable
   clone. This does not authorize page mapping, I/O, framebuffer access, or
   other hardware tests.
2. Confirm the VM's exact config and executable still match the reported
   paths, version, hash, S3 model, and VRAM setting. Verify how the VM starts
   and stops.
3. Confirm the copy is detached from the original disk and has no shared
   writable guest directories. Preserve the original disk and config
   read-only.
4. Recheck the helper's `manifest.json` and matching 277-file clone against
   `C:\\CODEX\\DOS`. Keep the separate rollback copy read-only and confirm
   it remains available before launching the clone.
5. Record SHA-256 hashes for the clone's config, backing disk(s), existing
   `SYSTEM.INI`, `WIN386.EXE`, and Windows SYSTEM directory inventory.
6. Confirm the guest's Windows system directory and inspect the clone's
   `[386Enh]` and `[boot]` settings read-only. Record the actual active VDD
   and baseline display driver. The expected report is stock VGA/`*VDDVGA`,
   but do not assume that reported state matches this specific clone.
7. Confirm a transfer mount from the project artifacts into the clone, its
   drive letter and write policy. The host mount `C:\\CODEX\\DOS` is
   reported; the guest drive letter must still be checked in the VM config.

## Ordinary canary startup-regression run

This optional step checks only whether the configured file disrupts startup.
It does not establish `Device_Init` dispatch. Skip it if the only desired
observation is the debugger-positive run below.

1. With the clone powered off, copy the ordinary `S3LDRCAN.386` into the
   verified Windows system directory (the previous runbook's example is
   `C:\WINDOWS\SYSTEM`; verify the path first).
2. In the clone's `SYSTEM.INI` only, add one line under `[386Enh]`:
   `device=S3LDRCAN.386`. Do not change `[boot]`, the display driver, VDD,
   DOSBox-X S3 mode, or any other setting.
3. Record the changed `SYSTEM.INI` hash and exact staged binary hash from the
   backing disk after transfer. Cold-start the clone normally and observe
   boot status, USER/font progress, and whether Program Manager appears.
   Label a clean desktop only as “startup completed with the canary
   configured”; do not report a positive VxD load or handler call.
4. If a hang, GPF, warning, or boot failure occurs, stop the VM and discard
   the clone. Do not attempt recovery by editing the source image.

## Positive `Device_Init` dispatch run

This is a distinct run using the debug image and a debug Windows kernel.
It can positively observe handler entry only if the debugger is compatible
and attached before VxD initialization.

1. Start from the verified disposable clone and its pre-run manifest. First
   test the existing DOSBox-X debugger before modifying the guest: at a DOS
   prompt, open the built-in debugger, issue `BPINT 03`, and confirm the
   debugger accepts the command. This uses DOSBox-X already present and
   installs no software. If the debugger is unavailable or the breakpoint
   command is rejected, stop this route and do not stage the INT 3 image.
2. With the clone powered off, copy only `S3LDRDBG.386` to the verified
   Windows SYSTEM directory. Add only `device=S3LDRDBG.386` under
   `[386Enh]` in the clone's `SYSTEM.INI`.
3. Cold-start the clone with the DOSBox-X interrupt breakpoint active. The
   expected stop occurs before interrupt 3 is dispatched. Record the
   debugger's CS:EIP and registers; verify `EAX=1`, `EBX` identifies the
   System VM as defined by the WfW contract, and the byte immediately before
   the stop address is `CC` with the canary's nearby `cmp eax,1 / je`
   dispatch sequence. Preserve the debugger transcript. Continue once and
   record whether `clc; ret` completes and Windows reaches the desktop.
4. If the stop is not positively attributable to the canary's `Device_Init`,
   if `EAX` or `EBX` differs unexpectedly, the debugger behavior is
   uncertain, or startup fails, stop and discard that clone. A clean desktop
   alone is not positive evidence.
5. A correctly attributed breakpoint establishes that this exact guest
   dispatched `Device_Init` for this candidate image. It still does not
   establish general WfW ABI conformance or any PM API, S3, VDD, or graphics
   function.

## Removal and rollback

For a cleanly completed run, shut Windows down and power off the clone. Remove
the single `device=...` line and the staged canary file from that clone's
system directory, then compare the restored `SYSTEM.INI`, system-directory
inventory, and other recorded files with the pre-run manifest. Because adding
the file can change directory metadata or FAT timestamps, the stronger
rollback is to discard the test clone and restore a fresh copy from the
untouched baseline snapshot. On any crash/hang or uncertain state, discard the
clone without booting it again. Preserve the original guest and its config.

## Strict scope boundary and evidence to retain

This no-output test must not call `_MapPhysToLinear`, `_PhysIntoV86`,
`_Assign_Device_V86_Pages`, `Install_IO_Handler`, or any VMM page/trap service.
It must not load the S3 DDA, program a mode, access a port, map/read/write the
framebuffer, or run a DOS application. Those are separate mapping/ownership
tests requiring separate authorization and contract evidence.

Retain the guest identity and config, baseline/rollback manifest, staged
binary hash, `SYSTEM.INI` before/after, boot result, and (for positive proof)
the DOSBox-X debugger transcript with the `Device_Init` breakpoint/register
state. No guest command or installation has been executed for this plan.

## Remaining prerequisites and permission

The clone/rollback paths and host executable/config have been identified by
the helper, but guest-side SYSTEM path and transfer-drive mapping remain to be
verified. The bounded canary is authorized. Positive proof can use the
existing DOSBox-X debugger if its build and `BPINT 03` behavior pass the
non-mutating preflight. No WDEB386 or other software installation is
authorized or needed for that emulator-debugger route. No page-mapping or
page-assignment work is included.
