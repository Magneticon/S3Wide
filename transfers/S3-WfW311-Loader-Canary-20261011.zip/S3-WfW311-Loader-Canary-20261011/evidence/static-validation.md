# S3LDRCAN static LE/DDB validation — 2026-10-11

## Scope and result

This is a read-only host inspection of the separate project-authored
`S3LDRCAN.386` no-I/O loader canary in `/workspace/s3wide-recovery`. No binary
was rebuilt or modified. The existing static checks pass, and Open Watcom's
`wdump` confirms an LE Win386 image, one exported DDB at ordinal 1, and one
fixup for its control-procedure pointer. `wdis` confirms the no-I/O control
dispatcher machine code. This validates the image against the retained
Open Watcom candidate declaration; it does **not** validate WfW 3.11 loader
acceptance or DDB conformance.

The 397-byte RET-only linker probe from the prior report is separate and
invalid as a VxD canary. It contains no DDB. The inspected project canary is
500 bytes, but remains unvalidated in a WfW guest.

## Inputs and reproducible checks

Run from `/workspace/s3wide-recovery` with the already installed toolchain:

```sh
python3 tests/vxd-loader-canary/check_candidate_source.py \
  tests/vxd-loader-canary/include/win30vxd.inc
python3 tests/vxd-loader-canary/inspect.py \
  tests/vxd-loader-canary/build/S3LDRCAN.386 \
  tests/vxd-loader-canary/build/s3ldrcan.map
/tmp/ow-linux-x64/binl64/wdump -a -e -f -p \
  tests/vxd-loader-canary/build/S3LDRCAN.386
/tmp/ow-linux-x64/binl64/wdis \
  tests/vxd-loader-canary/build/s3ldrcan.obj
```

Observed results: both Python static checks exit 0; `wdump` and `wdis` exit 0.
The source checker pins the Open Watcom include hash and checks the candidate
service constants, zero API/service initializers, and `EAX` dispatch compare.
The binary inspector checks the emitted fields against that same include and
the linker map. `wdump` independently parses the LE tables and fixup; `wdis`
decodes the linked routine from the object. The latter two are format and
machine-code inspections, not an independent Windows ABI validator.

Recorded SHA-256 values:

| Input/output | SHA-256 |
| --- | --- |
| `tests/vxd-loader-canary/include/win30vxd.inc` | `13c2711313419f9144972a670b93627ca92246640b25910c7d29d9d73010ab13` |
| `tests/vxd-loader-canary/src/s3ldrcan.asm` | `ac52a9c6ca82bc5084bc341aa7fd1fe8d2e2db3fb733e2815ef30d6a13fc89cd` |
| `tests/vxd-loader-canary/build/S3LDRCAN.386` | `ec34a802e00bf4235ba314ae683e0ff73edcbefe8486ef396b4582c8a46b72cf` |
| `wdump` used for inspection | `0312a12ffd712ed335fc87cd79ae39915f920661e93b9257ba8fb3723715ab6a` |
| `wdis` used for inspection | `c9db6cfc46bb2ffede72f5017f8810d9e1e02b6ca4a9dc97119cac87c8104acd` |

## LE image structure

`file` identifies the image as an MS-DOS executable containing an LE Windows
3.10 VxD 386 image. `wdump -a -e -f -p` reports:

* MZ header is 0x80 bytes; MZ relocation count is zero.
* LE signature is at file offset `0x80`; CPU type `2`, OS type `4` (Win386).
* Module flags are `0x8020` (`LIBRARY | NO_EXT_FIXUPS`); there is one 4-KiB
  page and one object. The object is readable, executable, preloaded, and
  `BIG`, with virtual size `0x5c` and relocation base `0x10000`.
* Object page 1 maps to file offset `0x188`.
* The resident module name is `S3LDRCAN`. The entry table has one `ENTRY32`
  export: ordinal 1, object 1, object offset `0x0c`. This is the start of the
  candidate DDB in the object.

The project linker response file requests `system win_vxd` and
`export S3LDRCAN_DDB.1`; it does not request the separate `dynamic` form.
Open Watcom's [linker guide, §2.3.17](https://open-watcom.github.io/open-watcom-v2-wikidocs/lguide.pdf)
distinguishes static VxDs for Windows 3.x/9x from dynamic VxDs for Windows
3.11/9x. That is a format-target distinction only; it does not establish that
this DDB record or image loads in WfW 3.11.

## DDB bytes and fixup

The candidate DDB begins at file offset `0x194` (object offset `0x0c`), and
the eight-byte name is at file offset `0x1a0`. The emitted 80 bytes decode as:

| DDB offset | Field | Emitted value |
| ---: | --- | --- |
| `0x00` | Next DDB | `00000000` |
| `0x04` | SDK version | `030a` |
| `0x06` | Requested device ID | `0000` (`UNDEFINED_DEVICE_ID`) |
| `0x08` | Major/minor | `1.0` |
| `0x0a` | Flags | `0000` |
| `0x0c` | Name | `S3LDRCAN` |
| `0x14` | Init order | `80000000` |
| `0x18` | Control procedure pointer | file value `00000001`, relocated by LE fixup |
| `0x1c`, `0x20` | V86 and PM API procedure pointers | zero |
| `0x24`, `0x28` | V86 and PM API CS:IP | zero |
| `0x2c` | Reference data | zero |
| `0x30`, `0x34` | Service-table pointer/size | zero |
| `0x38` | Win9x service-table tail field | zero |
| `0x3c` | Win9x previous-DDB tail field | zero |
| `0x40` | Win9x DDB size field | `00000050` (80 bytes) |
| `0x44`, `0x48`, `0x4c` | Reserved tail fields | zero |

The LE fixup page table contains one fixup. The fixup record is source object 1,
source offset `0x24`, target object 1, target offset `0x01`, flags `0x00`.
Since DDB object offset is `0x0c`, source offset `0x24` is exactly
`DDB + 0x18`, the control-pointer field. The target offset `0x01` is the first
instruction of `S3LDRCAN_Control`, matching the map/disassembly. This confirms
the on-disk relocation relationship; only the Windows loader can settle its
runtime interpretation in the target guest.

The 56-byte prefix and 24-byte tail above are exactly what the retained
licensed Open Watcom `win30vxd.inc` candidate declares and what this build
emits. The tail fields are explicitly labeled Windows 9x/Me in that include.
Neither `wdump` nor the candidate include establishes whether WfW 3.11 ignores
or accepts the tail, requires a different SDK version or device-ID policy, or
accepts this static LE/DDB combination.

## Control-dispatch machine code

`wdis` on the linked object reports the ordinary canary's control routine as:

```text
0000  90             nop
0001  83 F8 01       cmp eax,0x00000001
0004  74 02          je  Device_Init handler
0006  F8             clc
0007  C3             ret
0008  F8             clc
0009  C3             ret
```

The ordinary image performs no I/O, allocation, mapping, or S3/framebuffer
access. It returns carry clear for every message. For `EAX=1` (`Device_Init`),
the comparison branches to a second `clc; ret`; for all other messages the
first `clc; ret` handles them. The separate debug build adds `INT 3` at the
Device_Init target and is only intended for a WDEB386-attached debugging
WIN386. Its breakpoint has not been run.

## What requires a WfW 3.11 guest

Only a test on the exact identified disposable WfW 3.11 guest can establish
whether that loader accepts this `SDK=0x030A`, ID-zero, 80-byte candidate DDB
in a static LE image, tolerates the 9x/Me tail, applies the DDB control-pointer
fixup as expected, and dispatches `Device_Init` with the documented inputs.
A clean desktop alone would only show that startup completed with the image
configured; it would not prove that Win386 accepted the canary or called its
handler. A positive control-path observation requires the separate debugger
image, a working WDEB386-compatible debugging kernel, a breakpoint hit in the
handler with the expected message/register state, and successful continuation
to the desktop.

Even that result would validate only this no-API loader canary on that exact
guest. It would not validate a nonzero private VxD ID, INT 2Fh/1684h PM API
discovery, API-call ABI, VMM service availability/numbers, VDD/grabber
compatibility, trap or page assignment, S3 state virtualization, mode/bank
programming, framebuffer access, or Windows GDI acceptance. No guest action
or hardware operation was performed for this report.
