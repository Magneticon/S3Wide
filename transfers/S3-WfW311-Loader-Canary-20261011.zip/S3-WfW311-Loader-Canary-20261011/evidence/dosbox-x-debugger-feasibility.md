# Existing DOSBox-X debugger as a Device_Init canary observer

## Read-only source finding

The already available DOSBox-X source checkout is clean at commit
`b60936a716c72e0978e940f813bab2cd40d43868`. Its `README.debugger`
documents a built-in debugger with a CPU register panel and a `BPINT`
interrupt-breakpoint command. In `src/cpu/core_normal/prefix_none.h`, the
`INT3` instruction calls `DEBUG_IntBreakpoint(3)` and stops before
dispatching interrupt 3 when the core is compiled with `C_DEBUG`. This is a
source-level feasibility result, not runtime evidence for the reported
`C:\\DOSBox-X\\dosbox-x.exe`.

The active executable is consumer-reported as DOSBox-X 2026.08.31 with SHA-256
`2980380AB589A561EEDA3028AB955BC27137BD1710533B325F41144ECD460801`. Whether
that exact binary has `C_DEBUG` enabled, exposes the interactive debugger,
and accepts `BPINT 03` remains unknown. The user reports no WDEB386 files in
the inspected paths. Do not install a debugger or replace the existing
executable for this test.

## Bounded use

If the existing emulator debugger opens on the unchanged disposable clone
and accepts `BPINT 03` at a DOS prompt, that interrupt breakpoint can observe
the debug canary's `INT 3` before the guest's interrupt handler runs. This
may avoid the need for debug `WIN386.EXE` and WDEB386. The debug canary
contains no port access, VMM calls, mappings, framebuffer access, or S3
operations. The point of the test is only to observe its
`Device_Init` control dispatch.

The breakpoint must be attributed to the canary before calling it positive:
record CS:EIP and EAX/EBX, verify `EAX=1`, confirm EBX matches the documented
System-VM value, and inspect the byte at CS:EIP-1 plus nearby instructions to
match the canary's `cmp eax,1; je; int 3` sequence. An unrelated INT 3 or a
clean desktop is not sufficient. If the debugger is unavailable, the command
is rejected, the registers differ, or the code location cannot be matched,
stop and discard that clone; do not allow the INT 3 to fall through to a
retail Windows kernel.

No guest command was issued and no canary was loaded while preparing this
note. The findings use only the existing source checkout and the consumer's
reported executable metadata. No DOSBox-X code or binary was copied into the
canary package.
