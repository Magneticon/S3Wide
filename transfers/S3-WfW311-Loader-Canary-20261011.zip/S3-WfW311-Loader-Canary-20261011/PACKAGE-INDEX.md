# S3 WfW 3.11 no-output loader canary package

This archive contains the licensed Open Watcom candidate VxD declaration, project-authored no-I/O canary source, reproducible build/static checks and existing outputs, static LE/DDB validation, and a disposable-guest runbook updated with the helper-reported clone/config paths and source-verified DOSBox-X debugger feasibility.

Primary outputs:
- `canary/build/S3LDRCAN.386`: ordinary no-I/O static loader canary. SHA-256: `ec34a802e00bf4235ba314ae683e0ff73edcbefe8486ef396b4582c8a46b72cf`.
- `canary/build-debug/S3LDRDBG.386`: separate debug canary with an INT 3 at the Device_Init branch. SHA-256: `ed2ed0e42996d2576b5f30ea3782d219d6d8c0332422bfcfddab78e2a434d9f2`. Use only after the existing DOSBox-X debugger preflight accepts `BPINT 03`, or with a matching WDEB386 debugger/debug WIN386 route; never allow an unhandled INT 3 to reach a retail kernel.

Neither image is an S3 provider. Neither performs port I/O, page mapping/assignment, or framebuffer access. The ordinary image only gives a startup-regression observation; positive Device_Init evidence requires the debug image under a matching debugging WIN386 with WDEB386 attached before boot, and a recorded breakpoint stop with EAX=1 and System-VM context in EBX. See `evidence/guest-runbook.md`.

See `evidence/dosbox-x-debugger-feasibility.md` for the exact source finding and the unverified active-binary condition. The existing binaries and build records were verified read-only; this packaging step did not rebuild them or touch any guest. Hash all files with `PACKAGE-MANIFEST.sha256` before use.
